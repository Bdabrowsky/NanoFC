

bool initLoRa(bool DEBUG_OUTPUT)
{
    LoRa.setPins(8,9,7);

    if(!LoRa.begin(433E6)) 
    {
        if(DEBUG_OUTPUT)
            Serial.println("Starting LoRa failed!");
        return false;  
    }
    return true;
}


void sendPacket(string s)
{
    LoRa.beginPacket();
    LoRa.print(s);
    LoRa.endPacket();
}