#include <Adafruit_BMP280.h>
#include "Queue.h"

Adafruit_BMP280 bmp;

//Barometer stuff
float altitude=0,groundPressure,maxAltitude;
Queue<float> prevAltitude = Queue<float>(10);


void getAltitude(float &altitude, int aAC)
{
    float top,sum=0,alt;
    
    alt=bmp.readAltitude(groundPressure);
    prevAltitude.push(alt);
  
     //Rolling average of altitude
     top=prevAltitude.peek();
     prevAltitude.pop();
     sum+=top;

    for(int i=0;i<aAC-1;i++)
    {
        top=prevAltitude.peek();
        prevAltitude.pop();
        sum+=top;
        prevAltitude.push(top);
    }
  
  
    maxAltitude=max(maxAltitude,altitude);

    altitude=sum/aAC;

}

float getMaxAltitude()
{
    return maxAltitude;
}

void barometerCalibration(int aAC)
{
    float reading;
    groundPressure=bmp.readPressure();

    for(int i=0;i<aAC;i++)
    {
      reading=bmp.readAltitude(groundPressure);
      prevAltitude.push(reading);
    }
}

bool initBaro(int aAC,bool DEBUG_OUTPUT)
{
    if(!bmp.begin(0x76)) 
    {
        if(DEBUG_OUTPUT)
            Serial.println("Could not find a valid BMP085 sensor, check wiring!");
        return false;
    }
    if(DEBUG_OUTPUT)
        Serial.println("Found BMP sensor!");
    barometerCalibration(aAC);

    /* Default settings from datasheet. */
    bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,     /* Operating Mode. */
    Adafruit_BMP280::SAMPLING_X2,     /* Temp. oversampling */
    Adafruit_BMP280::SAMPLING_X16,    /* Pressure oversampling */
    Adafruit_BMP280::FILTER_X16,      /* Filtering. */
    Adafruit_BMP280::STANDBY_MS_500); /* Standby time. */

    return true;

}
