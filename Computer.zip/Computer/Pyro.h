void initPyro()
{
    
  //Attach pyro channels to given pins
  pinMode(2,OUTPUT);
  pinMode(3, OUTPUT);

}



void triggerPyro(int channel, bool DEBUG_OUTPUT)
{
  switch(channel)
  {
    case 1:
        digitalWrite(20,HIGH);
        if(DEBUG_OUTPUT)
            Serial.print("Pyro ");Serial.print(channel);Serial.println(" fired!");
      break;
    case 2:
        digitalWrite(21,HIGH);
        if(DEBUG_OUTPUT)
            Serial.print("Pyro ");Serial.print(channel);Serial.println(" fired!");
      break;
  }
}
