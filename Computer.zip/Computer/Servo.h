#include <Servo.h>


Servo Xp; //X+
Servo Xm; //X-
Servo Zp; //Z+
Servo Zm; //Z-

float pitch,yaw,roll;
float T,deltaT,prevT;



void initServo()
{
    //Attach servos to the given pins
    Xp.attach(10);
    Xm.attach(11);
    Zp.attach(12);
    Zm.attach(13);

    
    Xp.write(90);
    Xm.write(90);
    Zp.write(90);   
    Zm.write(90); 

}


void stabilize(float desiredPitch, float desiredRoll, float desiredYaw)
{
    int servoValueZ,servoValueX;
    
    T=millis();
    deltaT=T-prevT;
    prevT=T;
    
    Xp.write(servoValueX);
    Zm.write(servoValueZ);

}
