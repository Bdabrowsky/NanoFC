#include <Arduino_LSM6DS3.h>

float gOX,gOY,gOZ;


void getRawReadings(float & ax, float & ay, float & az, float & gx, float & gy, float & gz)
{ 
    if (IMU.gyroscopeAvailable()) 
    {
      IMU.readGyroscope(gx, gy, gz);
    }
    if (IMU.accelerationAvailable()) 
    {
      IMU.readAcceleration(ax, ay, az);
    }

    ax*=9.81;
    ay*=9.81;
    az*=9.81;

    gx*=PI/180.0;
    gy*=PI/180.0;
    gz*=PI/180.0;

    gx-=gOX;
    gy-=gOY;
    gz-=gOZ;
}

void calibrateGyro(int gyroCalibrationSampleCount)
{
  float avgX,avgY,avgZ;
  float gx,gy,gz;
  //Take given number of samples 
  for(int i=0;i<gyroCalibrationSampleCount;i++)
  {
    if (IMU.gyroscopeAvailable()) 
    {
      IMU.readGyroscope(gx, gy, gz);
    }
    avgX+=gx*=PI/180.0;;
    avgY+=gy*=PI/180.0;;
    avgZ+=gz*=PI/180.0;;
  }
    avgX/=(float)gyroCalibrationSampleCount;
    avgY/=(float)gyroCalibrationSampleCount;
    avgZ/=(float)gyroCalibrationSampleCount;

    gOX=avgX;
    gOY=avgY;
    gOZ=avgZ;
}

bool initIMU(int gCSC, bool DEBUG_OUTPUT)
{
    float ax,ay,az,gx,gy,gz;
    if(!IMU.begin())
    {
        if(DEBUG_OUTPUT)
            Serial.println("Unable to initialize the LSM9DS1. Check your wiring!");
        return false;
    }
    if(DEBUG_OUTPUT)
        Serial.println("Found LSM9DS1 9DOF");

    calibrateGyro(gCSC);

    return true;

}
