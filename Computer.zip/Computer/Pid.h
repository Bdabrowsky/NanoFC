
float previousErrorX,previousErrorY,previousErrorZ;
float globalKp;
float globalKd;
float globalKi;
float errorX,errorY,errorZ;
float pidX_P,pidZ_P,pidX_I,pidZ_I,pidX_D,pidZ_D;
float pidX,pidZ;




void initPid(double kp, double ki, double kd) 
{
    globalKp = kp;
    globalKi = ki;
    globalKd = kd;
}


void PIDcompute(float pitch, float yaw, float roll, float desiredPitch, float desiredYaw, float desiredRoll, float timeStep, int &servoValueX, int &servoValueZ, float pitchOffset, float rollOffset) 
{
    previousErrorX=errorX;
    previousErrorY=errorY;
    previousErrorZ=errorZ;

    errorX=pitch-desiredPitch;
    errorY=yaw-desiredYaw;
    errorZ=roll-desiredRoll;

    //proportional part
    pidX_P=errorX*globalKp;
    pidZ_P=errorZ*globalKp;

    //integral part
    pidX_I=globalKi*(pidX_I+errorX/timeStep);
    pidZ_I=globalKi*(pidZ_I+errorZ/timeStep);

    //derivative part
    pidX_D=globalKd*(errorX-previousErrorX)/timeStep;
    pidZ_D=globalKd*(errorZ-previousErrorY)/timeStep;


    //sum all p i d components
    pidX=pidX_P+pidX_I+pidX_D;
    pidZ=pidZ_P+pidZ_I+pidZ_D;

    servoValueX=pidX-pitchOffset;
    servoValueZ=pidZ-rollOffset;

    
}
    
